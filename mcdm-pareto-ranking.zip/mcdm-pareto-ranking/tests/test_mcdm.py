import os
import sys

import numpy as np
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
from mcdm import epsilon_constraint, topsis, weighted_sum  # noqa: E402

# Rows are alternatives, columns are criteria to minimise. Row 1 is the balanced compromise.
F = np.array([[1.0, 9.0, 5.0],
              [4.0, 4.0, 5.0],
              [9.0, 1.0, 5.0],
              [5.0, 5.0, 9.0]])


def test_all_weight_on_one_criterion_picks_its_minimum():
    for j in range(3):
        w = np.eye(3)[j]
        assert weighted_sum(F, w)[0][0] == np.argmin(F[:, j])
        assert topsis(F, w)[0][0] == np.argmin(F[:, j])


def test_weighted_sum_and_topsis_prefer_the_balanced_design_with_equal_weights():
    w = [1, 1, 1]
    assert weighted_sum(F, w)[0][0] == 1
    assert topsis(F, w)[0][0] == 1


def test_epsilon_constraint_puts_feasible_alternatives_first_and_sorted():
    order, feasible = epsilon_constraint(F, primary=0, eps={1: 5.0})
    assert list(order[:feasible.sum()]) == [1, 3, 2]   # criterion 1 <= 5, sorted by criterion 0
    assert list(order[feasible.sum():]) == [0]         # row 0 violates the cap and comes last
    assert not feasible[0]


def test_rankings_are_permutations():
    for order in (weighted_sum(F, [1, 2, 3])[0], topsis(F, [1, 2, 3])[0],
                  topsis(F, [1, 2, 3], norm="minmax")[0],
                  epsilon_constraint(F, 0, {1: 6.0})[0]):
        assert sorted(order) == list(range(len(F)))


def test_invalid_weights_raise():
    with pytest.raises(ValueError):
        weighted_sum(F, [1, 1])
    with pytest.raises(ValueError):
        topsis(F, [-1, 1, 1])
