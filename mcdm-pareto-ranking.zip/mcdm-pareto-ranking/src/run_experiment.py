"""Generate a Pareto front for the toy satellite problem and rank it with three MCDM methods."""
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy.stats import kendalltau
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.optimize import minimize
from pymoo.util.nds.non_dominated_sorting import NonDominatedSorting

from problem import SatelliteConfigProblem, OBJECTIVE_NAMES
from mcdm import weighted_sum, topsis, epsilon_constraint

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "results")
os.makedirs(OUT, exist_ok=True)
NAMES = ["mass_kg", "cost_keur", "data_gb_day"]


def build_front(seed=1):
    res = minimize(SatelliteConfigProblem(), NSGA2(pop_size=120), ("n_gen", 250), seed=seed, verbose=False)
    F, X = res.F, res.X
    keep = NonDominatedSorting().do(F, only_non_dominated_front=True)
    F, X = F[keep], X[keep]
    _, uniq = np.unique(np.round(F, 3), axis=0, return_index=True)   # drop near-duplicates
    uniq = np.sort(uniq)
    return F[uniq], X[uniq]


def display(F):
    D = F.copy()
    D[:, 2] = -D[:, 2]                      # show data volume as a positive number
    return D


def main():
    F, X = build_front()
    n = len(F)
    print(f"Pareto-optimal configurations: {n}")
    front = pd.DataFrame(display(F), columns=NAMES)
    front[["panel_m2", "cell_efficiency", "battery_wh", "battery_wh_per_kg", "antenna_m"]] = X
    front.to_csv(os.path.join(OUT, "pareto_front.csv"), index_label="id")

    scenarios = {
        "balanced":     [1/3, 1/3, 1/3],
        "mass-focused": [0.6, 0.2, 0.2],
        "cost-focused": [0.2, 0.6, 0.2],
        "data-focused": [0.2, 0.2, 0.6],
    }

    # 1. Rankings per scenario
    rows, ranks = [], {}
    for name, w in scenarios.items():
        ws_order, _ = weighted_sum(F, w)
        tp_order, _ = topsis(F, w)
        ranks[name] = (ws_order, tp_order)
        tau, _ = kendalltau(np.argsort(ws_order), np.argsort(tp_order))
        tm_order, _ = topsis(F, w, norm="minmax")
        tau_mm, _ = kendalltau(np.argsort(ws_order), np.argsort(tm_order))
        rows.append({"scenario": name, "weights(mass,cost,data)": [round(x, 2) for x in w],
                     "WS_top1": int(ws_order[0]), "TOPSIS_top1": int(tp_order[0]),
                     "same_top1": bool(ws_order[0] == tp_order[0]),
                     "kendall_tau": round(float(tau), 3),
                     "tau_vs_TOPSIS_minmax": round(float(tau_mm), 3),
                     "top10_overlap": len(set(ws_order[:10]) & set(tp_order[:10]))})
    summary = pd.DataFrame(rows)
    summary.to_csv(os.path.join(OUT, "scenario_summary.csv"), index=False)
    print(summary.to_string(index=False))

    # 2. Epsilon-constraint: sweep a cost cap, maximise data volume, mass capped at 60th percentile
    mass_cap = np.percentile(F[:, 0], 60)
    eps_rows = []
    for cap in np.linspace(F[:, 1].min(), F[:, 1].max(), 12):
        order, feasible = epsilon_constraint(F, primary=2, eps={0: mass_cap, 1: cap})
        eps_rows.append({"cost_cap_keur": round(float(cap), 1), "n_feasible": int(feasible.sum()),
                         "best_id": int(order[0]), "best_data_gb_day": round(float(-F[order[0], 2]), 2)})
    eps = pd.DataFrame(eps_rows)
    eps.to_csv(os.path.join(OUT, "epsilon_constraint_sweep.csv"), index=False)

    # 3. Weight sweep
    w_cost = np.linspace(0.02, 0.96, 60)
    ws_pick, tp_pick, agree = [], [], []
    for wc in w_cost:
        w = [(1 - wc) / 2, wc, (1 - wc) / 2]
        a, _ = weighted_sum(F, w)
        b, _ = topsis(F, w)
        ws_pick.append(a[0]); tp_pick.append(b[0])
        agree.append(kendalltau(np.argsort(a), np.argsort(b))[0])
    changes_ws = int(np.sum(np.diff(ws_pick) != 0))
    changes_tp = int(np.sum(np.diff(tp_pick) != 0))
    same_top1 = float(np.mean(np.array(ws_pick) == np.array(tp_pick)))
    print(f"top-1 changes across the cost-weight sweep: weighted-sum {changes_ws}, TOPSIS {changes_tp}")
    print(f"share of weights where both methods pick the same top-1: {same_top1:.2f}")
    print(f"Kendall tau between WS and TOPSIS rankings: mean {np.mean(agree):.3f}, min {np.min(agree):.3f}")

    D = display(F)

    fig, ax = plt.subplots(1, 3, figsize=(14, 4.2))
    for a_, (i, j) in zip(ax, [(0, 1), (0, 2), (1, 2)]):
        a_.scatter(D[:, i], D[:, j], s=14, alpha=0.6, color="#1F3A5F")
        for name, (ws_o, tp_o) in ranks.items():
            a_.scatter(D[ws_o[0], i], D[ws_o[0], j], marker="o", s=70, facecolors="none", edgecolors="#d95f02")
            a_.scatter(D[tp_o[0], i], D[tp_o[0], j], marker="x", s=60, color="#1b9e77")
        a_.set_xlabel(OBJECTIVE_NAMES[i]); a_.set_ylabel(OBJECTIVE_NAMES[j])
    ax[0].scatter([], [], marker="o", s=70, facecolors="none", edgecolors="#d95f02", label="weighted-sum top-1")
    ax[0].scatter([], [], marker="x", s=60, color="#1b9e77", label="TOPSIS top-1")
    ax[0].legend(loc="upper left", fontsize=8)
    fig.suptitle(f"Pareto front ({n} configurations) and the top-ranked choice per weight scenario")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig1_pareto_projections.png"), dpi=150); plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(12, 4.2))
    ax[0].plot(w_cost, D[ws_pick, 1], label="weighted-sum pick", color="#d95f02")
    ax[0].plot(w_cost, D[tp_pick, 1], label="TOPSIS pick", color="#1b9e77", linestyle="--")
    ax[0].set_xlabel("weight on cost (rest split equally)"); ax[0].set_ylabel("cost of chosen design [kEUR]")
    ax[0].set_title("Chosen design as the cost weight grows"); ax[0].legend()
    ax[1].plot(w_cost, agree, color="#1F3A5F")
    ax[1].set_ylim(-1.05, 1.05); ax[1].axhline(0, color="grey", lw=0.6); ax[1].set_xlabel("weight on cost"); ax[1].set_ylabel("Kendall tau (WS vs TOPSIS)")
    ax[1].set_title("Agreement between the two full rankings")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig2_weight_sweep.png"), dpi=150); plt.close(fig)

    fig, ax = plt.subplots(figsize=(6.2, 4.2))
    ax.plot(eps["cost_cap_keur"], eps["best_data_gb_day"], marker="o", color="#1F3A5F")
    ax.set_xlabel("cost cap (epsilon) [kEUR]"); ax.set_ylabel("best data volume [GB/day]")
    ax.set_title("Epsilon-constraint: best data volume under a cost cap\n(mass capped at the 60th percentile)")
    fig.tight_layout(); fig.savefig(os.path.join(OUT, "fig3_epsilon_constraint.png"), dpi=150); plt.close(fig)

    with open(os.path.join(OUT, "key_numbers.txt"), "w") as fh:
        fh.write(f"pareto_size={n}\nchanges_ws={changes_ws}\nchanges_topsis={changes_tp}\n"
                 f"same_top1_share={same_top1:.2f}\nmean_tau={np.mean(agree):.3f}\nmin_tau={np.min(agree):.3f}\n")


if __name__ == "__main__":
    main()
