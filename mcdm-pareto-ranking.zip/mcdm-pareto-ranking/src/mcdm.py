"""Three multi-criteria decision-making (MCDM) methods for ranking Pareto-optimal designs.

Every function expects a matrix F of shape (n_alternatives, n_criteria) in which
ALL criteria are to be MINIMISED, and returns the alternative indices ordered from
best to worst (plus the method's score).
"""
import numpy as np


def minmax_normalise(F):
    lo, hi = F.min(axis=0), F.max(axis=0)
    return (F - lo) / np.where(hi - lo == 0, 1.0, hi - lo)


def _check_weights(w, n):
    w = np.asarray(w, dtype=float)
    if w.shape != (n,) or np.any(w < 0) or w.sum() <= 0:
        raise ValueError("weights must be non-negative, one per criterion, with a positive sum")
    return w / w.sum()


def weighted_sum(F, w):
    """Weighted-sum: score = sum_j w_j * normalised f_j; lower is better."""
    w = _check_weights(w, F.shape[1])
    score = minmax_normalise(F) @ w
    return np.argsort(score, kind="stable"), score


def topsis(F, w, norm="vector"):
    """TOPSIS: closeness to the ideal point and distance from the anti-ideal point.

    Normalisation (`norm`), weighting, then closeness = d_neg / (d_pos + d_neg); higher is better.
    norm="vector" is the classic TOPSIS choice; norm="minmax" uses the same scaling as the
    weighted-sum method, which isolates the effect of the aggregation rule itself.
    """
    w = _check_weights(w, F.shape[1])
    if norm == "minmax":
        V = minmax_normalise(F) * w
    else:
        length = np.linalg.norm(F, axis=0)
        V = (F / np.where(length == 0, 1.0, length)) * w
    ideal, anti = V.min(axis=0), V.max(axis=0)     # all criteria are costs
    d_pos = np.linalg.norm(V - ideal, axis=1)
    d_neg = np.linalg.norm(V - anti, axis=1)
    closeness = d_neg / np.where(d_pos + d_neg == 0, 1.0, d_pos + d_neg)
    return np.argsort(-closeness, kind="stable"), closeness


def epsilon_constraint(F, primary, eps):
    """Epsilon-constraint: minimise one criterion while capping the others.

    `eps` maps criterion index -> upper bound. Feasible alternatives are ranked by the
    primary criterion; infeasible ones follow, ordered by how much they violate the caps.
    """
    violation = np.zeros(F.shape[0])
    for j, cap in eps.items():
        violation += np.maximum(0.0, F[:, j] - cap) / max(abs(cap), 1e-9)
    feasible = violation == 0
    order_feasible = np.where(feasible)[0][np.argsort(F[feasible, primary], kind="stable")]
    order_infeasible = np.where(~feasible)[0][np.argsort(violation[~feasible], kind="stable")]
    return np.concatenate([order_feasible, order_infeasible]), feasible
