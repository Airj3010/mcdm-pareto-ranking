"""Toy small-satellite configuration problem (synthetic, for demonstration only).

Decision variables
    A    solar panel area                 [m^2]    0.5 .. 4.0
    eta  solar cell efficiency            [-]      0.14 .. 0.32
    C    battery capacity                 [Wh]     100 .. 600
    rho  battery energy density           [Wh/kg]  80 .. 250
    D    antenna diameter                 [m]      0.2 .. 2.0

Objectives (all converted to MINIMISE)
    f1  total mass                        [kg]
    f2  total cost                        [kEUR]
    f3  - data volume per day             [GB/day]   (negated: we want more data)

Constraint
    the battery must cover the eclipse load of the platform and radio.

Why the objectives conflict
    * Higher cell efficiency and higher battery energy density cut mass but raise cost.
    * A bigger antenna, more panel area and more battery raise the data volume, and also mass and cost.

The formulas are simplified engineering-style relations. They are NOT real mission data.
"""
import numpy as np
from pymoo.core.problem import ElementwiseProblem

OBJECTIVE_NAMES = ["Mass [kg]", "Cost [kEUR]", "Data volume [GB/day]"]


def evaluate_config(A, eta, C, rho, D):
    """Return (mass, cost, data_gb_per_day, required_battery_wh)."""
    load_w = 40.0 + 25.0 * D**2                                  # platform + radio load [W]
    mass = 25.0 + 2.5 * A + C / rho + 6.0 * D**2
    cost = (250.0
            + A * (40.0 + 1200.0 * eta**2)                       # efficient cells are expensive
            + C * (0.15 + 0.004 * (rho - 80.0))                  # dense batteries are expensive
            + 90.0 * D**2)
    usable_w = 0.6 * 250.0 * eta * A + 0.12 * C                  # solar + battery contribution [W]
    duty = min(1.0, usable_w / load_w)                           # share of time the radio can run
    data = 100.0 * D**2 * duty                                   # downlink volume [GB/day]
    required_battery = 0.72 * load_w                             # Wh to survive the eclipse
    return mass, cost, data, required_battery


class SatelliteConfigProblem(ElementwiseProblem):
    def __init__(self):
        super().__init__(
            n_var=5, n_obj=3, n_ieq_constr=1,
            xl=np.array([0.5, 0.14, 100.0, 80.0, 0.2]),
            xu=np.array([4.0, 0.32, 600.0, 250.0, 2.0]),
        )

    def _evaluate(self, x, out, *args, **kwargs):
        A, eta, C, rho, D = x
        mass, cost, data, req = evaluate_config(A, eta, C, rho, D)
        out["F"] = [mass, cost, -data]                           # minimise all three
        out["G"] = [req - C]                                     # feasible when battery >= requirement
